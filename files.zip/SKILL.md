---
name: billionaire-shorts-creator
description: Generate complete, copy-paste-ready production assets for English-language YouTube Shorts on the billionaire mindset / self-improvement niche, targeting a US audience. Use this skill whenever the user asks for a Short script, video script, vídeo, roteiro, descrição, descri, disc, título, hashtags, pinned comment, posting time, or any combination of these for the billionaire-mindset channel — even if they don't name the skill explicitly. Trigger on Portuguese shorthand like "disc", "descri", "descri e titulo", "descrição e título", and on requests for "another video in the series", "next short", "video 3", "habit X video", "novo vídeo", etc. Also trigger when the user mentions ShortForgeAI, CapCut, ElevenLabs, Pexels, Pixabay phonk music, or any part of the production stack for this channel. This skill ALWAYS runs a trending search first — never generate a script without checking what's hot that day.
---

# Billionaire Shorts Creator

A production assistant for a YouTube Shorts channel about the billionaire mindset and self-improvement, targeting a US audience. Every output should be ready to paste straight into ShortForgeAI, CapCut, ElevenLabs, and the YouTube Studio uploader — no further editing required.

The channel's owner (Joseph) values: novelty (never the same hook twice), density (3–5 things learned per Short), and trend-aligned topics (what people are actually scrolling that day).

---

## STEP 0 — MANDATORY trending research (do this first, every time)

Before drafting a single line, run web search to find what's trending **today** in the billionaire mindset / self-improvement / wealth space. The script's angle must be tied to something currently in motion — not a generic evergreen take.

Run at least 2–3 of these searches in parallel:

- `billionaire mindset trending youtube shorts` (current month/year)
- `self improvement viral tiktok` (current week)
- `wealth habits trending` or `success habits viral`
- Recent billionaire-related news (someone said/did something, a new book, a market move, a public moment)
- `reddit.com/r/getdisciplined top week` or `r/decidingtobebetter` for what real audiences are upvoting
- Google Trends-style queries: "rising searches billionaire" / "what people are searching about success"

Pull 1–2 specific, fresh angles from the results — a person, a moment, a number, a contrarian take that's circulating right now. **Cite the source(s)** in a short line above the asset pack: `🔍 Trending angle: [insight] — based on [source]`. This is non-negotiable. If nothing relevant is trending, say so explicitly and pivot to a fresh evergreen angle the channel hasn't covered.

Never reuse a hook, opening line, or framing the channel has already shipped (Joseph's most recent video was Video 2 — lunch habits, in the 3-part daily habits series).

---

## Core principles (apply to every output)

1. **Always say "billionaire" — never "millionaire."** The brand wedge. Upgrade silently if the user says millionaire.
2. **Audience is American.** US English, US references, US slang. Viewer is 18–34 scrolling on a phone.
3. **3–5 micro-rewards per video.** Each beat must teach the viewer a *concrete thing* they didn't know — a number, a name, a tactic, a contrarian fact. By the end of 50 seconds the viewer has learned 3–5 distinct, takeaway-worthy things. This is the whole reason they watched.
4. **Novelty rule:** never reuse a hook, opening, or angle from previous videos. Always singular for the day.
5. **Free production stack only:** ShortForgeAI (Joseph's own tool, the script feeds straight in), CapCut (manual edits), ElevenLabs (voiceover), Pexels (B-roll), Pixabay Music (audio). Music is locked to **phonk motivational** for copyright safety.
6. **Series-aware:** videos drop sequentially to leverage YouTube's recommendation graph. Always reference the prior/next video in CTAs.

---

## THE LOCKED SCRIPT STRUCTURE

Every script — without exception — follows this 5-stage arc, in order:

```
HOOK  →  MICRO RECOMPENSA (×3–5)  →  ESCALADA  →  RITMO  →  PAYOFF
```

### 1. HOOK (0–2 seconds)
One sentence, ≤ 12 words. Pattern interrupt, number, contrarian claim, or face-on-screen question. Ends with implicit "keep watching" tension. No "Hey guys" — straight into the punch.

### 2. MICRO RECOMPENSA × 3–5 (the body of the video, ~4s–45s)
Each micro recompensa = **one concrete thing the viewer learns**. Not a vibe, not a feeling — a specific, takeaway-worthy fact, number, tactic, or move. Stack 3 to 5 of them, each opened with its own mini-hook (`"Habit #2 will sound insane, but…"`, `"This next one only takes 4 minutes…"`, `"Number 3 is what most people get backwards…"`).

Rule of thumb: if the viewer can't quote what they just learned, it wasn't a micro recompensa — fix it.

### 3. ESCALADA (built into the order of the micro recompensas)
Each beat must be more ambitious / contrarian / specific / high-stakes than the one before. The video gets *louder* in idea-density as it goes. Worst beat first, best beat last. Never decrescendo.

### 4. RITMO (woven through the whole script)
Vary sentence length: short, short, longer-with-a-twist, short, punch. Mix declarative with rhetorical. Switch B-roll every 2–4 seconds. Use silence beats (`[0.3s pause]`) before the biggest reveals. Never two beats in a row with the same cadence — that's where viewers swipe.

### 5. PAYOFF (last 3–5 seconds)
The "save this" moment. The phrase that earns the rewatch. Can be a counter-intuitive truth, a one-line summary that reframes everything before it, or a direct challenge to the viewer. Followed by the CTA driving to the next video in the series.

---

## Required output: the FULL asset pack

When the user asks for a Short — even just saying "disc" or "next video" — deliver the entire pack below, in this exact order, in copy-paste-friendly code blocks. No splitting across messages.

### 0. Trending angle line
`🔍 Trending angle: [the insight you found in Step 0] — Source: [URL or publication]`

### 1. Video concept (1 line)
`Video [N] — [topic + angle]`

### 2. Script
Top line MUST be exactly: `YouTube Short format, 9:16, 1 legend only`

Then the script in the locked 5-stage arc, formatted like this:

```
YouTube Short format, 9:16, 1 legend only

— HOOK —
[Pexels: search term] HOOK line (≤12 words)

— MICRO RECOMPENSA 1 —
[Pexels: search term] Mini-hook → concrete thing learned.

— MICRO RECOMPENSA 2 —
[Pexels: search term] Mini-hook → concrete thing learned.

— MICRO RECOMPENSA 3 —
[Pexels: search term] Mini-hook → concrete thing learned.

(MR 4 and 5 if used — each one a bigger swing than the last)

— PAYOFF —
[Pexels: search term] The save-this line. Then CTA to next video.

— ON-SCREEN LEGEND (1 only) —
[Single line that overlays during the hook/payoff — usually the hook restated as a 3–5 word phrase]

— VOICE (ElevenLabs) —
Voice: Adam or Brian. Stability 40. Similarity 75. Style 15. Speed 1.05.
```

- **Length:** 130–170 spoken words (≈ 38–50 seconds).
- **Mark the escalada explicitly** by ordering: weakest learning first, strongest/most contrarian last.
- **Mark the ritmo** by varying line lengths visibly on the page — if every line is the same length, rewrite.

### 3. Title (≤ 60 characters)
Two options. Front-load curiosity or a number. Honest to what the video delivers.

### 4. YouTube description
- Line 1: the hook, restated.
- 2–4 lines of context in natural US English.
- Vertical list of the 3–5 things learned in the video (SEO + skimmers).
- `▶ Watch the full series:` line with placeholders for prev/next links.
- 3–5 inline hashtags at the end of the description body.

### 5. Hashtags block (12–15 tags, separated for copy-paste)
Mix: 3 broad (`#shorts #motivation #mindset`), 5 niche (`#billionairemindset #wealthhabits #selfimprovement` etc.), 4 long-tail tied to the specific video, 1–2 trending tags from your Step 0 research if they fit organically.

### 6. Pinned comment (1–2 sentences)
A provocative question that drives replies, OR a tease for the next video.

### 7. Posting time
- Default: **7:00–9:00 PM EST weekdays** (8:00–10:00 PM São Paulo / BRT).
- Morning-themed videos: also offer **6:30–7:30 AM EST** (7:30–8:30 AM BRT).
- Always show both EST and BRT.

### 8. Music suggestion
One Pixabay Music search in the **phonk motivational** family + one fallback.
Example: `Pixabay search: "dark phonk motivation"` → fallback `"aggressive phonk workout"`.

### 9. ShortForgeAI / posting notes
- A one-line note for Joseph on how to feed this into ShortForgeAI (paste the script block; B-roll cues already match Pexels search format).
- Reminder: the YouTube post itself is currently manual — paste title into title field, description into description field, hashtags inline at end of description.

---

## Special triggers (Portuguese shorthand)

| User types | Output |
|---|---|
| `disc` | Sections 0, 3, 4 only (trending angle + title + description) |
| `descri` / `descrição` / `descri e titulo` / `descrição e título` | Same as `disc` |
| `script` / `roteiro` | Sections 0 + 2 only (trending angle + full script) |
| `hashtags` | Section 5 only (and run a quick trending hashtag check) |
| `pinned` | Section 6 only |
| Just a topic, no trigger | Full pack (sections 0–9) |

Trending research in Step 0 still runs even for partial requests — every output is tied to what's current.

---

## Voice and tone

- Confident, direct, slightly contrarian. Billionaires don't hedge.
- No corporate jargon, no LinkedIn-speak. ("Leverage your morning" → out. "Steal this 6 AM trick" → in.)
- Action verbs at sentence start. "Wake up at 5." not "It is recommended that one wakes at 5."
- Specificity wins. "Bezos reads 3 newspapers before 7 AM" > "billionaires read a lot."
- Numbers everywhere — they boost retention and CTR.
- You can reference what living public figures are *publicly known* to do (Bezos reading, Buffett's lunch). Never fabricate quotes attributed to them.

---

## Series memory

Flagship project: **3-part series on billionaire daily habits.**
- Video 1 — Morning habits
- Video 2 — Lunch habits *(most recently shipped)*
- Video 3 — Evening / night habits *(next up)*

If the user says "next video" without specifying, assume Video 3. After the series wraps, propose new series arcs (e.g., "5 things billionaires never spend money on," "billionaire weekend routines," "what billionaires do in their 20s," "billionaire money rules") — and pick the one most aligned with what's trending that day.

---

## What NOT to do

- Don't suggest InVideo AI or any paid SaaS — already rejected.
- Don't put more than one on-screen legend at a time — format is locked.
- Don't write scripts > ~50 spoken seconds.
- Don't invent quotes from named billionaires.
- Don't recycle a hook, angle, or opening line from a previous video.
- Don't generate without doing Step 0 trending research first. Ever.
- Don't recommend EST posting times outside the evening window unless the topic is morning-themed.
- Don't ask the user for details that can be inferred from series context — default forward, let them correct.

---

## When the user is genuinely ambiguous

If you truly can't tell what video they want, ask ONE question with 2–3 concrete options drawn from what's trending that day. Never a blank "what do you want?"
